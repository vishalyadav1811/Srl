package org.apache.jsp.pages.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.*;
import com.uav.constants.ApplicationConstants;

public final class login_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(2);
    _jspx_dependants.add("/pages/jsp/pageheader.jsp");
    _jspx_dependants.add("/pages/jsp/pagefooter.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

	String path =request.getParameter("pathparam"); 

      out.write('\n');
      out.write('\n');
      out.write("\n");
      out.write("<html lang=\"en\">\n");
      out.write("     \n");
      out.write("<head>\n");
      out.write("\n");
      out.write("\t\t<link rel=\"shortcut icon\" href=\"\" />\n");
      out.write("\t\t<link href=\"/tejas/pages/theme/solar/nonacl/images/favicon.ico?170902\" rel=\"shortcut icon\" />\n");
      out.write("\t\t<meta charset=\"UTF-8\" />\n");
      out.write("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
      out.write("\t\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n");
      out.write("\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no\">\n");
      out.write(" \n");
      out.write(" \n");
      out.write("\t\t<!-- 5 lines below added to disable the browser's cache --> \n");
      out.write("\t\t\n");
      out.write("\t\t<meta http-equiv=\"cache-control\" content=\"max-age=0\" />\n");
      out.write("\t\t<meta http-equiv=\"cache-control\" content=\"no-cache\" />\n");
      out.write("\t\t<meta http-equiv=\"expires\" content=\"0\" />\n");
      out.write("\t\t<meta http-equiv=\"expires\" content=\"Tue, 01 Jan 1980 1:00:00 GMT\" />\n");
      out.write("\t\t<meta http-equiv=\"pragma\" content=\"no-cache\" />\n");
      out.write("\t\t<!--end -->\n");
      out.write("\t\t\n");
      out.write("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />\n");
      out.write("\t\t<meta name=\"description\" content=\"Courier and Logistics Franchise System\" />\n");
      out.write("\t\t<meta content=\"TEJAS\" name=\"keywords\">\n");
      out.write("\t\t<meta content=\"follow,index\" name=\"robots\">\n");
      out.write("\t\t\n");
      out.write("\n");
      out.write(" \n");
      out.write("\n");
      out.write("\t\t<title>Cargo Operation | TEJAS</title>\n");
      out.write("\n");
      out.write("\t    <link href=\"/tejas/pages/theme/solar/nonacl/uav/css/login.css?20170909\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\">\n");
      out.write("\t \n");
      out.write("</head>\n");
      out.write("\n");
      out.write("<body>\n");
      out.write("\t  \n");
      out.write("\n");
      out.write("\t<!-- Start content container -->\n");
      out.write("\t<div>\n");
      out.write("\t\t<div id=\"content\" class=\"uav_clearfix\">\t\n");
      out.write("\t\t\t<!-- start login container -->\n");
      out.write("\t\t\t\t<div class=\"uav_loginpage\">\n");
      out.write("\t\t\t\t\t<div style=\"  text-align: center;\">\n");
      out.write("\t\t\t\t\t<h1 class=\"uav_login_header\">Sign in to your</h1>\n");
      out.write("\t\t\t\t\t<img  class=\"uav_login_header_img\" src=\"/tejas/pages/theme/solar/nonacl/images/logo.png\" /> \n");
      out.write("\t\t\t\t\t <h1  class=\"uav_login_header\">account</h1>\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t<div class=\"uav_login_container\">\n");
      out.write("\t\t\t\t\t\t<table width=\"100%\" id=\"outertable\" class=\"mobile-login\" style=\"\">\n");
      out.write("\t\t\t\t\t\t\t<tbody>\n");
      out.write("\t\t\t\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t<td align=\"center\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<div class=\"uav_alertmessage\">\n");
      out.write("\t\t\t\t\t\t\t\t\t        <button type=\"button\" class=\"uavclose\">Ã</button>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t <ul style=\"padding-left:16px\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t </ul>\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<div id =\"loginform\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<form name=\"login\" id=\"login\"  method=\"post\" novalidate=\"\" class=\"\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table id=\"inntbl\" class=\"mob_width\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody><tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"top\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table width=\"260\" class=\"mob_width\" cellpadding=\"1\" cellspacing=\"2\" align=\"center\">\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody> \n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\" align=\"center\"><span id=\"msgpanel\" class=\"hide\"></span></td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t   <td class=\"label\">Email:</td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t   \t\t   <td align=\"left\"><input type=\"email\"  id=\"signInId\"  name=\"signInId\"  class=\"input usrbx\" value=\"\"  ></td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"label\">Password:</td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td align=\"left\"><input type=\"password\" id=\"password\" name=\"password\"  class=\"input passbx\"  ></td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"label\"></td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td align=\"left\"><div class=\"forgotpasslink\"><span onclick=\"goToForgotPassword();\">Forgot Password?</span></div>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td></tr>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr id=\"hiptr\" style=\"display:none;\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t    <td class=\"label\">&nbsp;</td><td align=\"left\">&nbsp;</td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"emptytd\"></td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td height=\"30\" class=\"mobile-height\">\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"sectxt\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"rememberMe\" id=\"rememberMe\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"securetxt\">Keep me signed in</span>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</label>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"emptytd\"></td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td align=\"left\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button  type=\"submit\" id=\"signInBtn\"   class=\"submit_mobile\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tSign In\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t \t\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody></table>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t \n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t</form>\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t\t\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t\t\t\t\t</td>\n");
      out.write("\t\t\t\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t\t\t\t</tbody>\n");
      out.write("\t\t\t\t\t\t</table>\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t<!-- end login container -->\n");
      out.write("\n");
      out.write("\t\t\t<!-- start password reset container -->\n");
      out.write("\t\t\t\t<div class=\"uav_passreset\" >\n");
      out.write("\n");
      out.write("\t\t\t\t\t<div style=\"  text-align: center;\">\n");
      out.write("\t\t\t\t\t\t<img  class=\"uav_passreset_img\" src=\"/tejas/pages/theme/solar/nonacl/images/logo.png\" /> \n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\n");
      out.write("\t\t\t\t\t<div class=\"uav_passreset_title1\"  >\n");
      out.write("\t\t\t\t\t\tPassword Reset Request\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t<div class=\"uav_bdr1\"></div>\n");
      out.write("\t\t\t\t\t<div class=\"uav_alertmessage\" style=\"width:500px; margin:0 auto;\">\n");
      out.write("\t\t\t\t\t        <button type=\"button\" class=\"uavclose\">Ã</button>\n");
      out.write("\t\t\t\t\t\t\t <ul style=\"padding-left:16px\">\n");
      out.write("\t\t\t\t\t\t\t </ul>\t\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\n");
      out.write("\t\t\t\t\t<div class=\"uav_passreset_title2\">\n");
      out.write("\t\t\t\t\t\t\tEnter your email address in the space below and we will mail you the password reset instructions\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t\t\t<div>\n");
      out.write("\t\t\t\t\t\t\t<div class=\"unauthlabel\">\n");
      out.write("\t\t\t\t\t\t\t\t<input type=\"email\" name=\"fgtEmailid\" id=\"fgtEmailid\" class=\"unauthinputText\" placeholder=\"Registered Email\" value=\"\" >\n");
      out.write("\t\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t\t\t<div class=\"button\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<span class=\"redBtn\" style=\"margin-right:0px;\" id=\"buttonloader\" tabindex=\"1\" onclick=\"forgotpassword();\">Request</span> \n");
      out.write("\t\t\t\t\t\t\t\t\t\t<span class=\"cancel-btn\" style=\"margin-left:6px;\" tabindex=\"1\" onclick=\"backtosignin();\">Back to Sign In</span>\n");
      out.write("\t\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t<!-- end password reset container -->\n");
      out.write("\n");
      out.write("\t\t\t<!-- start password reset message -->\n");
      out.write("\t\t\t\t<div class=\"uav_passreset_msg\" >\n");
      out.write("\t\t\t\t\t\t<div style=\"  text-align: center;\">\n");
      out.write("\t\t\t\t\t\t\t<img  class=\"uav_passreset_img\" src=\"/tejas/pages/theme/solar/nonacl/images/logo.png\" /> \n");
      out.write("\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t\t<div id=\"successmsgpanel\" class=\"successmsg_forgot\"><span id=\"successresp\"><span>An email with password reset link sent to your email address : <b></b>. Follow the instructions in the email to reset your account password and get back into your account.</span></span><div style=\"margin-top:10px;display:none;\" id=\"success_mobile_txt\">We have also sent you a text message with a recovery code in it. To use this code to initiate the password reset process, click <a href=\"{0}\">here</a>.</div><div class=\"mob_but_head\" style=\"text-align: center;margin-top: 8%\">\n");
      out.write("\t\t\t\t\t\t\t\t <span class=\"cancel-btn\" onclick=\"backtosignin()\">Back to home</span></div>\n");
      out.write("\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t<!-- end password reset message-->\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t</div>     \t  \n");
      out.write("\t</div>\n");
      out.write("\t<!-- End  content container -->  \n");
      out.write(" \n");
      out.write("\n");
      out.write("\t<div>\n");
      out.write("\t\t\t<div style=\"font-size:10px;text-align:center;padding:5px 0px;\">\n");
      out.write("\t\t\t\tÂ©&nbsp;2017,&nbsp;<a href=\"http://www.uavtechnologies.in/\" title=\"UAV Technologies\" target=\"_blank\" style=\"font-size:11px;color:#085ddc;\">UAV Technologies</a>&nbsp;All rights reserved.\n");
      out.write("\t\t\t</div>\n");
      out.write("\n");
      out.write("\t</div>\n");
      out.write("\n");
      out.write("\t\n");
      out.write("<!-- Start Modal -->\n");
      out.write("\t<div  id='uav-modal' class=\"modal\" >\n");
      out.write("\t  <div class=\"modal-content\" >\n");
      out.write("\t  </div>\n");
      out.write("\t</div>\n");
      out.write("\t<!-- End Modal -->\n");
      out.write("\t<!-- Start lean overlay div-->\n");
      out.write("\t<div class=\"lean-overlay\" id=\"uav-lean-overlay\" ></div>\n");
      out.write("\t<!-- End -->\n");
      out.write("<!-- loader svg -->\n");
      out.write("\t<div>\n");
      out.write("\t <svg  style=\"display: none;\"   version=\"1.1\" id=\"loader\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" \n");
      out.write("\t\t   width=\"40px\" height=\"40px\" viewBox=\"0 0 40 40\" enable-background=\"new 0 0 40 40\" xml:space=\"preserve\">\n");
      out.write("  <path opacity=\"0.2\" fill=\"#fff\" d=\"M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946\n");
      out.write("    s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634\n");
      out.write("    c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z\"/>\n");
      out.write("  <path fill=\"#fff\" d=\"M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0\n");
      out.write("    C22.32,8.481,24.301,9.057,26.013,10.047z\">\n");
      out.write("    <animateTransform attributeType=\"xml\"\n");
      out.write("      attributeName=\"transform\"\n");
      out.write("      type=\"rotate\"\n");
      out.write("      from=\"0 20 20\"\n");
      out.write("      to=\"360 20 20\"\n");
      out.write("      dur=\"0.5s\"\n");
      out.write("      repeatCount=\"indefinite\"/>\n");
      out.write("    </path>\n");
      out.write("  </svg> \n");
      out.write("  </div>\n");
      out.write("\t<!-- end -->\n");
      out.write("<script type=\"text/javascript\" src=\"/tejas/pages/theme/solar/nonacl/jquery/js/jquery.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/tejas/pages/theme/solar/nonacl/jquery/js/jquery.validate.min.js\"></script>\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"/tejas/pages/theme/solar/nonacl/uav/js/login.js\"></script>\n");
      out.write("<script>\n");
      out.write("\t\t//scroll top on refresh the page\n");
      out.write("\t\t$(window).on('beforeunload', function(){\n");
      out.write("  \t\t\t$(window).scrollTop(0);\n");
      out.write("\t\t});\n");
      out.write("\t\tvar lastScrollTop = 0;\n");
      out.write("\t\t$(window).scroll(function(event){\n");
      out.write("\t\t   \n");
      out.write("\t\t});\n");
      out.write("\t\t $(document).ready(function() {\n");
      out.write("\t\t\t\t$(this).scrollTop(0);\n");
      out.write("\t\t });\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("\n");
      out.write("</html>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
