package org.apache.jsp.pages.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.*;

public final class portallogin_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

  String url = "";
  String userAgent = request.getHeader("user-agent");
  if (userAgent.matches(".*Android.*")  || userAgent.matches(".*iPhone.*")    || userAgent.matches(".*iPad.*") || userAgent.matches(".*iPod.*") || userAgent.matches(".*iemobile.*") || userAgent.matches(".*blackberry.*")  || userAgent.matches(".*BB10.*") )
  {
	  url="/pages/jsp/mobile.jsp?pathparam="+request.getParameter("path") ;
  }
  else
  {
    url="/pages/jsp/desktop.jsp?pathparam="+request.getParameter("path") ;
  }
	
	RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
	dispatcher.forward(request,response);

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<script>\n");
      out.write("/*\t \n");
      out.write("\tfunction isMobile() {\n");
      out.write("       var path= window.location.pathname;\n");
      out.write("\t\tpath= path.replace(\"/tkameez/\",\"\");\n");
      out.write("\t    var dispatcherPath = path.split(\"/\");\n");
      out.write("\t\tif (dispatcherPath.length ==1){\n");
      out.write("\t\t\tvar url =\"/tkameez/pages/portal/theme/fashion/pages/mobile/wor/home.html\";\n");
      out.write("\t\t}else{\n");
      out.write("\t\t\tvar url =\"/tkameez/pages/portal/theme/fashion/pages/mobile/wor/home.html?path=\" +\tdispatcherPath.join(\"/\");\t\t\n");
      out.write("\t\t}\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t//alert(url);\n");
      out.write("\t\tvar requestParam= window.location.search ;\n");
      out.write("\t\tif(requestParam !=\"\"){\n");
      out.write("\t\t\tif(url.indexOf('?') != -1){\n");
      out.write("\t\t\t\trequestParam = requestParam.substring(1);\n");
      out.write("\t\t\t\turl += \"&\"+requestParam;\n");
      out.write("\t\t\t}else{\n");
      out.write("\t\t\t\turl += requestParam;\n");
      out.write("\t\t\t}\n");
      out.write("\t\t}\n");
      out.write("        var mBrowserHTML = url;\n");
      out.write("        var userAgent = navigator.userAgent || navigator.vendor || window.opera;\n");
      out.write("\n");
      out.write("\t\tif( userAgent.match( /iPad/i ) || userAgent.match( /iPhone/i ) || userAgent.match( /iPod/i ) ){\n");
      out.write("          \t\t\twindow.location.href=  mBrowserHTML ;\n");
      out.write("          }else if( userAgent.match( /Android/i )){\n");
      out.write("        \t\t\t  window.location.href=  mBrowserHTML ;\n");
      out.write("          }else if( userAgent.match( /blackberry/i ) ||  userAgent.match( /BB10/i )){\n");
      out.write("        \t\t\t  window.location.href=  mBrowserHTML ;\n");
      out.write("          }else if( userAgent.match( /iemobile/i ) ){\n");
      out.write("        \t\t\t  window.location.href=  mBrowserHTML ;\n");
      out.write("          }else{\n");
      out.write("          \t\twindow.location.href=\"/tkameez/pages/portal/theme/fashion/pages/wor/msiteonly.html\"          \n");
      out.write("          }\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\n");
      out.write("\n");
      out.write("   }\n");
      out.write("\n");
      out.write("\tisMobile();\n");
      out.write(" */\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
