package org.apache.jsp.pages.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.*;
import com.uav.constants.ApplicationConstants;

public final class rof_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

	String path =request.getParameter("pathparam"); 

      out.write("\n");
      out.write("\n");
      out.write("<html lang=\"en\">\n");
      out.write("     \n");
      out.write("<head>\n");
      out.write("\n");
      out.write("\t\t<link rel=\"shortcut icon\" href=\"\" />\n");
      out.write("\t\t<link href=\"pages/rof/images/favicon.ico?170902\" rel=\"shortcut icon\" />\n");
      out.write("\t\t<meta charset=\"UTF-8\" />\n");
      out.write("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
      out.write("\t\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n");
      out.write("\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no\">\n");
      out.write(" \n");
      out.write(" \n");
      out.write("\t\t<!-- 5 lines below added to disable the browser's cache --> \n");
      out.write("\t\t\n");
      out.write("\t\t<meta http-equiv=\"cache-control\" content=\"max-age=0\" />\n");
      out.write("\t\t<meta http-equiv=\"cache-control\" content=\"no-cache\" />\n");
      out.write("\t\t<meta http-equiv=\"expires\" content=\"0\" />\n");
      out.write("\t\t<meta http-equiv=\"expires\" content=\"Tue, 01 Jan 1980 1:00:00 GMT\" />\n");
      out.write("\t\t<meta http-equiv=\"pragma\" content=\"no-cache\" />\n");
      out.write("\t\t<!--end -->\n");
      out.write("\t\t\n");
      out.write("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />\n");
      out.write("\t\t<meta name=\"description\" content=\"Courier and Logistics Franchise System\" />\n");
      out.write("\t\t<meta content=\"ROF\" name=\"keywords\">\n");
      out.write("\t\t<meta content=\"follow,index\" name=\"robots\">\n");
      out.write("\t\t\n");
      out.write("\n");
      out.write(" \n");
      out.write("\n");
      out.write("\t\t<title>ROF | Welcome Bussiness Associates</title>\n");
      out.write("\n");
      out.write("\t    <link href=\"/rof/pages/theme/solar/css/uavstyle.css?20170901\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\">\n");
      out.write("</head>\n");
      out.write("\n");
      out.write("<body style=\"background-color:initial;font-family:'ProximaNovaRegular' !important \"  >\n");
      out.write("\t  \n");
      out.write("\n");
      out.write("\t<!-- Start content container -->\n");
      out.write("\t<div>\n");
      out.write("\t\t<div id=\"content\" style=\"overflow:hidden;margin-top: 56px;min-height:600px;\">\t\n");
      out.write("\t\t\tPayment Received\t\t\n");
      out.write("\t\t</div>     \t  \n");
      out.write("\t</div>\n");
      out.write("\t<!-- End  content container -->  \n");
      out.write("\n");
      out.write("\n");
      out.write("\t<!-- Start Modal -->\n");
      out.write("\t<div  id='uav-modal' class=\"modal\" >\n");
      out.write("\t  <div class=\"modal-content\" >\n");
      out.write("\t  </div>\n");
      out.write("\t</div>\n");
      out.write("\t<!-- End Modal -->\n");
      out.write("\t<!-- Start lean overlay div-->\n");
      out.write("\t<div class=\"lean-overlay\" id=\"uav-lean-overlay\" style=\"z-index: 1002; display: none; opacity: 0.5;\"></div>\n");
      out.write("\t<!-- End -->\n");
      out.write("\n");
      out.write("\n");
      out.write("<script>\n");
      out.write(" \n");
      out.write(" \n");
      out.write("\t\t//scroll top on refresh the page\n");
      out.write("\t\t$(window).on('beforeunload', function(){\n");
      out.write("  \t\t\t$(window).scrollTop(0);\n");
      out.write("\t\t});\n");
      out.write("\t\tvar lastScrollTop = 0;\n");
      out.write("\t\t$(window).scroll(function(event){\n");
      out.write("\t\t   \n");
      out.write("\t\t});\n");
      out.write("\t\t $(document).ready(function() {\n");
      out.write("\t\t\t \tuav.isMPage = true;\n");
      out.write("\t\t\t\t$(this).scrollTop(0);\n");
      out.write("\t\t\t\tvar heightNav=  parseInt($(\"#navtop\").css(\"height\"),10)   + parseInt($(\"#navcat\").css(\"height\"),10) + parseInt($(\"#navsearch\").css(\"height\"),10);\n");
      out.write("\t\t \n");
      out.write("\t\t\t\t$(\"#content\").css(\"margin-top\",heightNav+\"px\");\n");
      out.write("\t\t\t\t// menu click event\n");
      out.write("\t\t\t\t$(\".menuindicator\").click(function(){\n");
      out.write("\t\t\t\t\t$(\"#uav-lean-overlay\").css(\"display\",\"block\");\n");
      out.write("\t\t\t\t\t$(\".uav-mobile-menu-wrapper\").css(\"display\",\"block\");\n");
      out.write("\t\t\t\t\t$(\".uav-mobile-menu-wrapper\").addClass(\"uav-mobile-menu-changepos\");\n");
      out.write("\t\t\t\t});\n");
      out.write("\n");
      out.write("\t\t\t\t$(window).scroll(function () {\n");
      out.write("\t\t\t\t    if ($(this).scrollTop() > $('#navsearch').height()) {\n");
      out.write("\t\t\t\t      $('#navsearch').fadeOut();//.hide();\n");
      out.write("\t\t\t\t    }else{\n");
      out.write("\t\t\t\t      $('#navsearch').fadeIn();//.show();\n");
      out.write("\t\t\t\t    }\n");
      out.write("\t\t\t\t});\n");
      out.write("\n");
      out.write("\t\t\t\t$(\".uav-mobile-menu-body\").html(\"\");\n");
      out.write("\t\t\t\tmenu.getMenu();\n");
      out.write("\t \t\t\t\n");
      out.write("\t\t\t\t$(\"#uav-lean-overlay\").bind(\"click\", function(){\n");
      out.write("\t\t\t\t\t\t$(\"#uav-lean-overlay\").css({\"display\":\"none\"});\n");
      out.write("\t\t\t\t\t\t$(\"#uav-modal\").css({\"display\":\"none\"});\n");
      out.write("\t\t\t\t\t\t$(this).scrollTop(0);\n");
      out.write("\t\t\t\t\t\tmenu.hide();\n");
      out.write("\t\t\t\t});\n");
      out.write("\n");
      out.write("\t\t\t\tremoveCookies();\n");
      out.write("\t\t\t\t//checksession is used to check on home page load to get the cart data\n");
      out.write("\t\t\t\tchecksession();\n");
      out.write("\t\t\t\thomepage.bindEvent();\n");
      out.write("\t\t\t\thome.router = uav.pageaddressmobile.homecontent;\n");
      out.write("\n");
      out.write("\t\t\t\tvar requestParam = \"");
      out.print(path);
      out.write("\";\n");
      out.write("\n");
      out.write("\t\t\t\t//if no param load home(content)\n");
      out.write("\t\t\t\tif(requestParam=='' || requestParam==undefined || requestParam==null){\n");
      out.write("\t\t\t\t\thome.loadPage();\n");
      out.write("\t\t\t\t\treturn;\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\tvar params = requestParam.split(\"/\");\n");
      out.write("\t\t\t\t//if there is a response from payment gateway, load respective page\n");
      out.write("\t\t\t\tif(params[0]==\"order\"){\n");
      out.write("\t\t\t\t\thomepage.prepaidOrderStatus\t=params[1];\n");
      out.write("\t\t\t\t\thomepage.orderConfirmNumber =params[2];\n");
      out.write("\t\t\t\t\t\tif(homepage.prepaidOrderStatus!=null){\n");
      out.write("\t\t\t\t\t\t\tif(homepage.prepaidOrderStatus==\"success\"){\n");
      out.write("\t\t\t\t\t\t\t \thome.router = uav.pageaddressmobile.confirmedorder;\n");
      out.write("\t\t\t\t\t\t\t}else{\n");
      out.write("\t\t\t\t\t\t\t\thome.router = uav.pageaddressmobile.declinedorder;\n");
      out.write("\t\t\t\t\t\t\t}\n");
      out.write("\t\t\t\t\t\t\thome.loadPage();\n");
      out.write("\t\t\t\t\t\t\treturn;\n");
      out.write("\t\t\t\t\t\t}\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t\t\t//if there is a descriptive key and keytype, load respective url\n");
      out.write("\t\t\t\t\t//validate key and keytype\n");
      out.write("\t\t\t\t\tif(!homepage.validateKeytypeAndKey(requestParam)){\n");
      out.write("\t\t\t\t\t\t//if invalid, load home\n");
      out.write("\t\t\t\t\t\thome.loadPage();\n");
      out.write("\t\t\t\t\t\treturn;\n");
      out.write("\t\t\t\t\t}\n");
      out.write("\t\t\t\t\t//check if keytype is static\n");
      out.write("\t\t\t\t\tif(homepage.getUrlByStaticKeytype(requestParam)){\n");
      out.write("\t\t\t\t\t\t//if yes, load url\n");
      out.write("\t\t\t\t\t\thome.loadPage();\n");
      out.write("\t\t\t\t\t\treturn;\n");
      out.write("\t\t\t\t\t}\n");
      out.write("\t\t\t\t\t//else call(ajax) server to get url by key and keytype\t\n");
      out.write("\t\t\t\t\thomepage.getURLByKeytypeAndKey(requestParam);\n");
      out.write("\t\t\t\t\tsetTimeout(isAjaxCallComplete,1);      \n");
      out.write("\t\t\t\t\tfunction isAjaxCallComplete(){\n");
      out.write("\t\t\t\t\t    if(homepage.aliasData['ajaxCallComplete']) {\n");
      out.write("\t\t\t\t\t\thome.loadPage();\n");
      out.write("\t\t\t\t\t    }else{\n");
      out.write("\t\t\t\t\t    \tsetTimeout(isAjaxCallComplete,1);      \n");
      out.write("\t\t\t\t\t    }\n");
      out.write("\t\t\t\t\t}\n");
      out.write("\t\t });\n");
      out.write("\n");
      out.write("\tvar home = {\n");
      out.write("\t\trouter\t\t:null,\n");
      out.write("\t\tcookieId\t:null,\n");
      out.write("\t\tloadPage\t: function(){\n");
      out.write("\t\t\t\trenderHomePage.loadHTML(home.router, home.cookieId);\n");
      out.write("\t\t}\n");
      out.write("\n");
      out.write("\t};\n");
      out.write("</script>\n");
      out.write("</html>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
