package org.apache.jsp.pages.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.*;
import com.uav.context.UserContext;
import com.uav.constants.ApplicationConstants;
import com.uav.authservice.AuthService;
import com.uav.context.UserContext;
import com.uav.dataservice.CoreMasterDataService;
import java.util.Map;

public final class dpadmin_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(2);
    _jspx_dependants.add("/pages/theme/solar/acl/html/pageheader.html");
    _jspx_dependants.add("/pages/theme/solar/acl/html/pagefooter.html");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

	String path =request.getParameter("path");
	String paramString = "";
	Map<String, String[]> parameters = request.getParameterMap();
	for(String parameter : parameters.keySet()) {
	    if(!parameter.equals("path")) {
		String values = request.getParameter(parameter);
		paramString += (paramString.equals("")?"":"&");
		paramString += parameter + "=" + values;
	    }
	}
	if(!paramString.equals("")){
		path += "?" + paramString;
	}
	HttpSession session = request.getSession();
	UserContext userContext = (UserContext) session.getAttribute(ApplicationConstants.USERCONTEXT_CONSTANT);
	 
	String member = userContext.getMemberJSON() ;//CoreMasterDataService.getMemberPostLogin(userContext,null ) ;
	

      out.write('\n');
      out.write('\n');
      out.write("\n");
      out.write("<html lang=\"en\">\n");
      out.write("     \n");
      out.write("<head>\n");
      out.write("\n");
      out.write("\t\t<link rel=\"shortcut icon\" href=\"\" />\n");
      out.write("\t\t<link href=\"/dpadmin/pages/theme/solar/nonacl/images/favicon.ico?170902\" rel=\"shortcut icon\" />\n");
      out.write("\t\t<meta charset=\"UTF-8\" />\n");
      out.write("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
      out.write("\t\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n");
      out.write("\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no\">\n");
      out.write(" \n");
      out.write(" \n");
      out.write("\t\t<!-- 5 lines below added to disable the browser's cache --> \n");
      out.write("\t\t\n");
      out.write("\t\t<meta http-equiv=\"cache-control\" content=\"max-age=0\" />\n");
      out.write("\t\t<meta http-equiv=\"cache-control\" content=\"no-cache\" />\n");
      out.write("\t\t<meta http-equiv=\"expires\" content=\"0\" />\n");
      out.write("\t\t<meta http-equiv=\"expires\" content=\"Tue, 01 Jan 1980 1:00:00 GMT\" />\n");
      out.write("\t\t<meta http-equiv=\"pragma\" content=\"no-cache\" />\n");
      out.write("\t\t<!--end -->\n");
      out.write("\t\t\n");
      out.write("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />\n");
      out.write("\t\t<meta name=\"description\" content=\"Courier Door Pickup\" />\n");
      out.write("\t\t<meta content=\"door pickup\" name=\"keywords\">\n");
      out.write("\t\t<meta content=\"follow,index\" name=\"robots\">\n");
      out.write("\t\t\n");
      out.write("\n");
      out.write(" \n");
      out.write("\n");
      out.write("\t\t<title>Door Pickup</title>\n");
      out.write("\t    <link href=\"/dpadmin/pages/theme/solar/nonacl/jquery/css/jquery-ui.css\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\">\n");
      out.write("\t    <link href=\"/dpadmin/pages/theme/solar/nonacl/jquery/css/jquery.tree.min.css\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\">\n");
      out.write("\t    <link href=\"/dpadmin/pages/theme/solar/acl/uav/css/doorpickup.css?20170909\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\">\n");
      out.write("\t    <link href=\"/dpadmin/pages/theme/solar/acl/uav/css/animation.css?20170909\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\">\n");
      out.write("\t\t<link rel='stylesheet' id='ecoenergy-fontello-style-css'  href=\"/dpadmin/pages/theme/solar/acl/uav/css/fontello/css/fontello.css\" type='text/css' media='all' />\n");
      out.write("\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\"/dpadmin/pages/theme/solar/acl/uav/css/MonthPicker.css\">\n");
      out.write("\n");
      out.write("\t \n");
      out.write("</head>\n");
      out.write("\n");
      out.write("<script>\n");
      out.write("\tvar URLPATH = \"");
      out.print(path);
      out.write("\" ;\n");
      out.write("\n");
      out.write("\t// path could be null in case not path added in url or path was invalid in activity\n");
      out.write("\tif(URLPATH ==\"null\"){\n");
      out.write("\t\t\twindow.history.pushState('', '', '/dpadmin');\n");
      out.write("\t}\n");
      out.write("\tif (typeof(Storage) == \"undefined\") {\n");
      out.write("\t\talert(\"Sorry! No Web Storage support..\");\n");
      out.write("\t}\n");
      out.write("\tvar member=  ");
      out.print(member);
      out.write(";\n");
      out.write("</script>\n");
      out.write("<body>\n");
      out.write(" <div class=\"uav_main\">\t\n");
      out.write("\t<div class=\"comeforth-top\"></div>\n");
      out.write("\t<div class=\"uav_headerbar\">\n");
      out.write("\t\t\t<i class=\"fontello-search search\" style=\"padding-left: 90%;line-height: 50px;    color: blue;cursor: pointer;\" id=\"info\"></i>\n");
      out.write("\t\t<div class=\"rs\">\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t<div class=\"uic\">\n");
      out.write("\t\t\t\t<i class=\"fontello-user\"></i>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t</div>\n");
      out.write("\t</div>\n");
      out.write("\t<div class=\"uav_contentbody\">\n");
      out.write("\t\t<div class=\"uav_menubar uav_scrollbar\">\n");
      out.write("\t\t\t<div class=\"uav_menucontent\"></div>\n");
      out.write("\t\t\t<span class=\"uav-menu-toggle-nav\"><i class=\"navsign fontello-left-open-big\"></i></span>\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<div  class=\"uav_content uav_content_expended uav_scrollbar\">\n");
      out.write("\t\t \t \n");
      out.write("\t\t</div>\n");
      out.write("\t</div>\n");
      out.write("\t\n");
      out.write("</div>\n");
      out.write("</body>\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<!-- Start Modal -->\n");
      out.write("\n");
      out.write("\t\n");
      out.write("\t<div  id='uav-modal' class=\"modal uav_scrollbar\" >\n");
      out.write("\t  <div class=\"modal-content\" >\n");
      out.write("\t  </div>\n");
      out.write("\t</div>\n");
      out.write("\t<!-- End Modal -->\n");
      out.write("\n");
      out.write("\n");
      out.write("<!-- Start Modal for toast-->\n");
      out.write("  <div  id='uav-modal-toast' class=\"modal uav_scrollbar\" >\n");
      out.write("    <div class=\"modal-content-toast\" >\n");
      out.write("    </div>\n");
      out.write("  </div>\n");
      out.write("  <!-- End Modal -->\n");
      out.write("\n");
      out.write("\n");
      out.write("<!-- Start Modal for search at header bar  -->\n");
      out.write("  <div  id='uav-modal-search-entity' class=\"modal uav_scrollbar\" >\n");
      out.write("    <div class=\"modal-content-search-entity\" >\n");
      out.write("    </div>\n");
      out.write("  </div>\n");
      out.write("  <!-- End Modal -->\n");
      out.write("\n");
      out.write("\n");
      out.write("\t<!-- Start lean overlay div-->\n");
      out.write("\t<div class=\"lean-overlay\" id=\"uav-lean-overlay\" ></div>\n");
      out.write("\t<div id=\"loader\"  style=\"display: none; position: fixed; z-index: 22000; height: 100%;   width: 100%; background:black; opacity: .8;\">\t\n");
      out.write("\t\t    <div class=\"preloader-wrapper active\" style=\"position:fixed; top:50%; left:50%;\" >\n");
      out.write("\t\t\t\t<i  class=\"fontello-spin6 animate-spin\"></i>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t</div>\n");
      out.write("\t<!-- End -->\n");
      out.write("<!-- loader svg -->\n");
      out.write("\t<div>\n");
      out.write("\t <svg  style=\"display: none;\"   version=\"1.1\" id=\"loader\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" \n");
      out.write("\t\t   width=\"40px\" height=\"40px\" viewBox=\"0 0 40 40\" enable-background=\"new 0 0 40 40\" xml:space=\"preserve\">\n");
      out.write("  <path opacity=\"0.2\" fill=\"#fff\" d=\"M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946\n");
      out.write("    s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634\n");
      out.write("    c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z\"/>\n");
      out.write("  <path fill=\"#fff\" d=\"M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0\n");
      out.write("    C22.32,8.481,24.301,9.057,26.013,10.047z\">\n");
      out.write("    <animateTransform attributeType=\"xml\"\n");
      out.write("      attributeName=\"transform\"\n");
      out.write("      type=\"rotate\"\n");
      out.write("      from=\"0 20 20\"\n");
      out.write("      to=\"360 20 20\"\n");
      out.write("      dur=\"0.5s\"\n");
      out.write("      repeatCount=\"indefinite\"/>\n");
      out.write("    </path>\n");
      out.write("  </svg> \n");
      out.write("  </div>\n");
      out.write("\t<!-- end -->\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jquery.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jquery.validate.min.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jqueryPlugins/formatter/jquery.formatter.min.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jqueryPlugins/formatter/jquery.maskMoney.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jqueryPlugins/ui/jquery-ui.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jqueryPlugins/tree/jquery.tree.min.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jqueryPlugins/mask/jquery.mask.js\"></script>\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/nonacl/jquery/js/jqueryPlugins/MonthPicker/jquery.MonthPicker.js\"></script>\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\" ></script>\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/doorpickup.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/menu.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/httpconnection.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/localcache.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/elements.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/entryform.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/pagenationgrid.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/nopagenationgrid.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/util.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"/dpadmin/pages/theme/solar/acl/uav/js/tree.js\"></script>\n");
      out.write("<script>\n");
      out.write("  $( document ).tooltip();\n");
      out.write("\n");
      out.write("  var d = new Date();\n");
      out.write("  //var timestamp = d.getTime();\n");
      out.write("  var month = d.getMonth()+1;\n");
      out.write("  var day = d.getDate();\n");
      out.write("  var year=d.getFullYear();\n");
      out.write("  var value=day+\"/\"+month+\"/\"+  year;\n");
      out.write("\n");
      out.write("  var date2=Util_Date.getDateobject(value,'dmy', '/') ;\n");
      out.write(" \n");
      out.write("  \n");
      out.write("  \n");
      out.write("  \n");
      out.write("  http.getRequest.send(\"/rest/remote/getServerDateCache\" , responsegetServerDateCache);\n");
      out.write("  function responsegetServerDateCache(resp){\n");
      out.write("  \t    var valuedata=resp.dataList.date;\n");
      out.write("  \t\tvar  da= new Date(valuedata );\n");
      out.write("  \t\t\n");
      out.write("  \t\t\n");
      out.write("  \t\tvar month = da.getMonth()+1;\n");
      out.write("\t    var day = da.getDate();\n");
      out.write("\t    \n");
      out.write("\t    var year=da.getFullYear();\n");
      out.write("\t    var value1=day+\"/\"+month+\"/\"+  year;\n");
      out.write("\n");
      out.write("\t    var date3=Util_Date.getDateobject(value1,'dmy', '/') ;\n");
      out.write("\n");
      out.write("\t\t\n");
      out.write("     \tif(date2!=date3){\n");
      out.write("  \t\t\t\talert(\"Please set your system date\");\n");
      out.write("  \t\t\t}\n");
      out.write("  \t\t\t//console.log(date2+\"///\"+date3);\n");
      out.write("\n");
      out.write("  }\n");
      out.write("\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<script>\n");
      out.write("\t \n");
      out.write("\tfor(var cntr=0;cntr<20; cntr++){\n");
      out.write("\t\t$('#menuul').append(\"<li>cntr</li>\");\n");
      out.write("\t}\n");
      out.write("\t\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\n");
      out.write("\t\t\n");
      out.write("\t\n");
      out.write("</script>\n");
      out.write("\n");
      out.write(" \n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
